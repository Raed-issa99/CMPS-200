a = "1 "
b = a + "2 " + a
c = b + "3 " + b
d = c + "4 " + c

print(a)
print(b)
print(c)
print(d)
