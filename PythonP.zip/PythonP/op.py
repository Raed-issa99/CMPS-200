print ('hello' , end = ' ')*4
