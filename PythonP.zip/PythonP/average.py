def average(a):
    total = 0.0
    for v in a:
        total += v
    return(total/len(a))


average([7, 2, 1, 5, 3]) #how do i print this value
    
