import string
s= string.ascii_letters
print(s)
