#Draws an down arrow
def down():
        print("* * *")
        print(" * *")
        print("  *")

#Draws a up arrow
def up():
        print("  *")
        print(" * *")
        print("* * *")


down()
up()
down()
up()Z
