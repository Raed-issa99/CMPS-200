import math

def compare(x,y):
    if x > y:
        return 1
    if x == y:
        return 0
    if x < y:
        return -1

print(compare(0, 1))
