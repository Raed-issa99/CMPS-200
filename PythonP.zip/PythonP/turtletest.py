import turtle
def polygon (t,n,lenght):
    angle=360/n
for i in range(n):
    t.forward(length)
    t.right(angle)
t=turtle.Turtle()
polygon(t,6,100)
