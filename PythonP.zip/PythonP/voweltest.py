def is_vowel(c):
    vowels = "aeiou"
    if c in vowels:
        return True
    else:
        return False
print(is_vowel('c'))
