i = [1,2,3,4,5]
i.pop(1)
print(i)
s = i.pop(3)
print(i)
print(s)
